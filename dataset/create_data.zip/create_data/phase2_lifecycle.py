﻿import os
import pandas as pd
import numpy as np
import random
import math
from datetime import datetime, timedelta
from faker import Faker

# [Professor Fix 1] 시드 및 날짜 고정
SEED_VAL = 42
random.seed(SEED_VAL)
np.random.seed(SEED_VAL)
Faker.seed(SEED_VAL)
fake = Faker('ko_KR') 

# [Professor Fix 1] 기준일자 고정
FIXED_TODAY_STR = "2026-02-10"
TODAY = datetime.strptime(FIXED_TODAY_STR, "%Y-%m-%d")
now = TODAY # 코드 내 now 변수 호환용

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data_lifecycle") # create_data/data_lifecycle
os.makedirs(DATA_DIR, exist_ok=True)

LIFE_VARIABILITY_FACTOR = 0.4  # 품목별 표준편차 반영 비율. 0.1은 수명이 지나치게 좁게 몰려 모델 평가가 쉬워짐.
MIN_LIFE_YEARS = 1.0
MAX_LIFE_CAP_FACTOR = 2.2
SIGMA_SCALING_FACTOR = LIFE_VARIABILITY_FACTOR  # 기존 변수명을 참조하는 코드/노트북 호환용 별칭
# ---------------------------------------------------------
# [NEW] 현실 기반 물품별 기대 수명 통계 (평균 μ, 표준편차 σ) - 단위: 년
# 출처: SquareTrade, ScienceDirect, Google Research, MS/OEM Guide 등
# ---------------------------------------------------------
REAL_LIFETIME_STATS = {
    # [IT 기기]
    "노트북": (4.3, 0.9),       # 보증사/연구 통계 기반
    "데스크톱": (5.0, 1.2),     # 기업 교체 주기 반영
    "모니터": (7.0, 1.5),       # LCD 패널 수명 고려
    "프린터": (6.0, 1.5),       # 레이저프린터 기준
    "스캐너": (6.5, 1.5),
    "라우터": (5.5, 1.5),       # 엔터프라이즈 장비 기준
    "하드디스크": (4.5, 1.2),   # HDD AFR 고려
    "서버": (6.0, 1.5),
    
    # [가구/시설]
    "랙": (15.0, 4.0),         # 철제 구조물
    "책상": (15.0, 3.5),       # 고품질 오피스 가구
    "실습대": (15.0, 3.5),
    "실험대": (15.0, 3.5),
    "보조장": (15.0, 3.5),
    "의자": (9.5, 2.0),        # 작업용/라운지 의자 평균
    "소파": (11.0, 3.0),
    "화이트보드": (7.0, 2.0),  # 인터랙티브(전자) 화이트보드
    
    # [기본값]
    "default": (8.0, 2.0)      # 매칭 안되는 품목용
}

FAILURE_PRONE_KEYWORDS = [
    "노트북", "데스크톱", "모니터", "프린터", "스캐너", "라우터", "하드디스크", "서버"
]

def sample_positive_life_years(item_name_norm: str, mu: float, sigma: float) -> float:
    """
    물품 수명을 양수 분포에서 샘플링한다.
    - IT/전자 장비: 시간이 지날수록 고장 위험이 커지는 Weibull 분포
    - 가구/시설/기타: 양수이면서 긴 꼬리를 갖는 Lognormal 분포
    정규분포 + 강한 표준편차 축소보다 교수 평가 시 설명 가능한 합성 데이터 근거를 만들기 쉽다.
    """
    adjusted_sigma = max(0.25, sigma * LIFE_VARIABILITY_FACTOR)

    if any(keyword in item_name_norm for keyword in FAILURE_PRONE_KEYWORDS):
        shape = 2.4 if any(keyword in item_name_norm for keyword in ["하드디스크", "라우터", "서버"]) else 3.0
        scale = mu / math.gamma(1 + 1 / shape)
        sampled = np.random.weibull(shape) * scale
    else:
        variance = adjusted_sigma ** 2
        log_sigma = np.sqrt(np.log1p(variance / max(mu ** 2, 1e-6)))
        log_mu = np.log(max(mu, MIN_LIFE_YEARS)) - 0.5 * log_sigma ** 2
        sampled = np.random.lognormal(log_mu, log_sigma)

    upper_cap = max(MIN_LIFE_YEARS + 0.5, mu + 3 * max(sigma, adjusted_sigma), mu * MAX_LIFE_CAP_FACTOR)
    return float(np.clip(sampled, MIN_LIFE_YEARS, upper_cap))

# ---------------------------------------------------------
# 반납/불용 사유 그룹 정의
# ---------------------------------------------------------
# 1. 반납 사유 (행정적/업무적 요인)
REASONS_RETURN = ['사업종료', '잉여물품', '공용전환']
PROBS_RETURN_REASON = [0.6, 0.15, 0.25]

# 2. 불용 사유 (물리적/규정적 요인)
# - 수명이 다했을 때 선택될 사유들. 활용부서부재/구형화는 행정적 반납에서 별도 생성한다.
REASONS_PHYSICAL_END = ['고장/파손', '노후화', '성능저하', '수리비용과다', '내용연수경과', '내구연한 경과(노후화)']
PROBS_PHYSICAL_END_REASON = [0.20, 0.25, 0.16, 0.17, 0.14, 0.08]

# 3. 대학 업무 캘린더 패턴
# - 2월/8월: 방학 및 학기 시작 전 기자재 점검으로 불용/교체 판단 증가
# - 12월: 예산 집행 및 연말 재물조사로 처분 확정 증가
DISUSE_REVIEW_WINDOWS = [(2, 1, 25), (8, 1, 25), (12, 1, 20)]
DISPOSAL_EXECUTION_WINDOWS = [(2, 10, 28), (8, 10, 31), (12, 1, 24)]
PROB_ALIGN_DISUSE_TO_ACADEMIC_CYCLE = 0.72
PROB_ALIGN_DISPOSAL_TO_BUDGET_CYCLE = 0.78

def pick_cycle_window_date(base_date, windows, max_days_ahead=180):
    """기준일 이후 가장 가까운 대학 업무 캘린더 윈도우 안의 날짜를 고른다."""
    base_ts = pd.to_datetime(base_date)
    if pd.isna(base_ts):
        return base_date
    base_dt = datetime(base_ts.year, base_ts.month, base_ts.day)
    if base_dt >= TODAY:
        return TODAY

    candidates = []
    for year in [base_dt.year, base_dt.year + 1]:
        for month, start_day, end_day in windows:
            window_start = datetime(year, month, start_day)
            window_end = datetime(year, month, end_day)
            if window_end < base_dt:
                continue
            if window_start < base_dt <= window_end:
                start = base_dt
            else:
                start = window_start
            if start > TODAY:
                continue
            if (start - base_dt).days > max_days_ahead:
                continue
            max_day = min(window_end, TODAY)
            if start <= max_day:
                days_span = (max_day - start).days
                candidates.append(start + timedelta(days=random.randint(0, max(0, days_span))))

    if not candidates:
        return base_dt
    return min(candidates)

def apply_institutional_cycle(base_date, event_type):
    """불용/처분 이벤트에 학사 일정과 예산 집행 주기를 확률적으로 반영한다."""
    if event_type == 'disuse' and random.random() < PROB_ALIGN_DISUSE_TO_ACADEMIC_CYCLE:
        return pick_cycle_window_date(base_date, DISUSE_REVIEW_WINDOWS, max_days_ahead=180)
    if event_type == 'disposal' and random.random() < PROB_ALIGN_DISPOSAL_TO_BUDGET_CYCLE:
        return pick_cycle_window_date(base_date, DISPOSAL_EXECUTION_WINDOWS, max_days_ahead=180)
    return pd.to_datetime(base_date).to_pydatetime()
# ---------------------------------------------------------
# 0. 설정 및 데이터 로드
# ---------------------------------------------------------
try:
    file_path = os.path.join(DATA_DIR, '03_01_acquisition_master.csv')
    df_acq = pd.read_csv(file_path)
    print(f"📂 [Phase 2] 취득 데이터 로드 완료: {len(df_acq)}건")
except FileNotFoundError:
    print("❌ 오류: '03_01_acquisition_master.csv' 파일이 없습니다. Phase 1을 먼저 실행해주세요.")
    exit()

# 사용자/부서 마스터 
ADMIN_USER = ("hyl0610", "황팀장")
STAFF_USER = ("badbergjr", "박대리")

# Phase 1의 부서 마스터 데이터 정의 (재사용 시 부서 재배정용)
DEPT_MASTER_DATA = [
    ("C354", "소프트웨어융합대학RC행정팀(ERICA)"),
    ("C352", "공학대학RC행정팀(ERICA)"),
    ("C364", "경상대학RC행정팀(ERICA)"),
    ("C360", "글로벌문화통상대학RC행정팀(ERICA)"),
    ("A351", "시설팀(ERICA)"),
    ("A320", "학생지원팀(ERICA)"),
    ("A124", "학생지원팀(서울)"),
    ("A125", "커리어개발팀(서울)"),
    ("C190", "사회과학대학RC행정팀(서울)"),
    ("C192", "자연과학대학RC행정팀(서울)"),
    ("C182", "공과대학RC행정팀(서울)"),
    ("C188", "인문과학대학RC행정팀(서울)"),
]

# ---------------------------------------------------------
# 시뮬레이션 확률 상수 정의 (Magic Numbers 제거)
# ---------------------------------------------------------
# 출력 상태 확률 (출력, 미출력)
PROBS_PRINT_STATUS = [0.8, 0.2]

# 반납 발생 확률
PROB_EARLY_RETURN = 0.01     # 초기 반납(신품, 잉여) 확률: 1%
PROB_RETURN_OVER_3Y = 0.05   # 3년 초과 반납 확률: 5%
PROB_RETURN_OVER_5Y = 0.15   # 5년 초과 반납 확률: 15%

# 승인 상태 (확정, 대기, 반려)
STATUS_CHOICES = ['확정', '대기', '반려']
# 최근 대기 상태 몰림 기준일
RECENT_WAIT_START = datetime(2024, 10, 1)  # 2024-10 이후

# 각 단계별 승인 상태 확률
PROBS_STATUS_RETURN = [0.85, 0.1, 0.05] 
PROBS_STATUS_DISUSE = [0.70, 0.25, 0.05] 
PROBS_STATUS_DISPOSAL = [0.93, 0.06, 0.01]

PROB_SURPLUS_STORE = 0.9  # 잉여물품 보관 확률 (불용 스킵)

# [NEW] 재사용 및 운용전환 관련 상수
PROB_REUSE_FROM_RETURN = 0.05   # 반납품 중 재사용(운용전환)될 확률 (5% - 아주 소수)
PROB_DIRECT_TRANSFER = 0.02     # 운용 중인 물품이 다른 부서로 바로 전환될 확률 (2% - 아주 소수)
RECENT_USE_LIMIT_DAYS = 365 * 2 # "사용한 지 얼마 안 된" 기준 (2년 이내)

# 처분 방식 확률 (신품/중고품일 때 vs 아닐 때)
METHODS_DISPOSAL = ['매각', '폐기', '멸실', '도난']
PROBS_DISPOSAL_GOOD = [0.85, 0.13, 0.01, 0.01] # 상태 좋음
PROBS_DISPOSAL_BAD = [0.03, 0.95, 0.01, 0.01]  # 상태 나쁨 

MAX_REUSE_CYCLES = 3     # 최대 재사용 횟수 제한

# ---------------------------------------------------------
# 1. 헬퍼 함수 & 데이터 구조 초기화
# ---------------------------------------------------------
# 결과 저장을 위한 전역 리스트
results = {
    'transfer': [], # 운용전환
    'return': [],   # 반납
    'disuse': [],   # 불용
    'disposal': [], # 처분
    'history': [],  # 이력
    'maintenance': [] # 점검/수리
}

def derive_usage_profile(item_name, dept_name, budget_grade="MEDIUM", management_tendency=1.0):
    """품목과 부서 특성으로 예측 시점에 알 수 있는 사용량/가동률 패턴을 만든다."""
    item = str(item_name)
    dept = str(dept_name)
    budget_grade = str(budget_grade)
    management_tendency = float(management_tendency) if pd.notna(management_tendency) else 1.0

    is_it = any(k in item for k in ["노트북", "데스크톱", "모니터", "프린터", "스캐너"])
    is_infra = any(k in item for k in ["라우터", "하드디스크", "서버", "네트워크"])
    is_furniture = any(k in item for k in ["책상", "의자", "소파", "탁자", "보조장"])
    is_lab_dept = any(k in dept for k in ["소프트웨어", "공학", "공과", "전산", "AI", "컴퓨터", "자연과학"])
    is_support_dept = any(k in dept for k in ["학생지원", "시설"])

    if is_infra:
        monthly_hours = random.randint(520, 720)
        weekly_days = random.choice([6, 7])
        shared = 1
        class_used = 0
        item_factor = 1.18
    elif is_it and is_lab_dept:
        monthly_hours = random.randint(120, 220)
        weekly_days = random.randint(4, 6)
        shared = 1 if random.random() < 0.75 else 0
        class_used = 1 if random.random() < 0.70 else 0
        item_factor = 1.12
    elif is_it:
        monthly_hours = random.randint(60, 150)
        weekly_days = random.randint(3, 5)
        shared = 1 if random.random() < 0.35 else 0
        class_used = 1 if random.random() < 0.20 else 0
        item_factor = 1.00
    elif is_furniture:
        monthly_hours = random.randint(80, 200)
        weekly_days = random.randint(3, 6)
        shared = 1 if random.random() < (0.75 if is_lab_dept or is_support_dept else 0.45) else 0
        class_used = 1 if random.random() < (0.45 if is_lab_dept else 0.20) else 0
        item_factor = 0.95
    else:
        monthly_hours = random.randint(30, 120)
        weekly_days = random.randint(2, 5)
        shared = 1 if random.random() < 0.30 else 0
        class_used = 1 if random.random() < 0.15 else 0
        item_factor = 0.92

    dept_factor = 1.15 if is_lab_dept else (1.05 if is_support_dept else 1.0)
    budget_factor = {"LOW": 0.96, "MEDIUM": 1.0, "HIGH": 1.04}.get(budget_grade, 1.0)
    shared_factor = 1.10 if shared else 1.0
    class_factor = 1.08 if class_used else 1.0
    hours_factor = np.clip(monthly_hours / 140.0, 0.75, 1.25)
    usage_intensity = item_factor * dept_factor * budget_factor * shared_factor * class_factor * hours_factor
    usage_intensity *= np.random.uniform(0.94, 1.06)
    usage_intensity = float(np.clip(usage_intensity, 0.80, 1.35))

    return {
        "월평균사용시간": int(monthly_hours),
        "주당사용일수": int(weekly_days),
        "공용장비여부": int(shared),
        "수업사용여부": int(class_used),
        "사용강도지수": round(usage_intensity, 3),
    }

def generate_maintenance_rows(df_operation, df_disuse, df_disposal):
    """운용 중 누적되는 점검/수리 이력을 생성한다. 기준일 또는 종료일 이후 이벤트는 만들지 않는다."""
    maintenance_rows = []

    end_date_map = {}
    if not df_disposal.empty:
        dp = df_disposal.copy()
        dp["처분기준일"] = pd.to_datetime(dp["처분확정일자"].replace("", pd.NA), errors="coerce").combine_first(
            pd.to_datetime(dp["처분일자"], errors="coerce")
        )
        end_date_map.update(dp.dropna(subset=["처분기준일"]).drop_duplicates("물품고유번호", keep="last").set_index("물품고유번호")["처분기준일"].to_dict())
    if not df_disuse.empty:
        du = df_disuse.copy()
        du["불용기준일"] = pd.to_datetime(du["불용확정일자"].replace("", pd.NA), errors="coerce").combine_first(
            pd.to_datetime(du["불용일자"], errors="coerce")
        )
        for asset_id, end_dt in du.dropna(subset=["불용기준일"]).drop_duplicates("물품고유번호", keep="last").set_index("물품고유번호")["불용기준일"].to_dict().items():
            end_date_map.setdefault(asset_id, end_dt)

    for row in df_operation.itertuples():
        asset_id = row.물품고유번호
        acq_date = pd.to_datetime(row.취득일자, errors="coerce")
        if pd.isna(acq_date):
            continue
        end_date = pd.to_datetime(end_date_map.get(asset_id, TODAY), errors="coerce")
        if pd.isna(end_date) or end_date <= acq_date + pd.Timedelta(days=90):
            continue

        item_name = str(row.G2B_목록명)
        usage_intensity = float(getattr(row, "사용강도지수", 1.0))
        management_tendency = float(getattr(row, "부서관리성향", 1.0))
        content_life = max(float(getattr(row, "내용연수", 5) or 5), 1.0)
        price = max(float(getattr(row, "취득금액", 0) or 0), 1.0)
        age_years = max((end_date - acq_date).days / 365.0, 0.1)

        is_failure_prone = any(k in item_name for k in FAILURE_PRONE_KEYWORDS)
        base_issue_rate = 0.24 if is_failure_prone else 0.10
        if "서버" in item_name or "네트워크" in item_name:
            base_issue_rate = 0.30
        if any(k in item_name for k in ["책상", "의자", "소파", "탁자"]):
            base_issue_rate = 0.07

        regular_expected = min(8, age_years / 2.2 * np.clip(management_tendency, 0.85, 1.15))
        age_pressure = 0.75 + min(age_years / content_life, 1.8) * 0.45
        issue_expected = min(7, age_years * base_issue_rate * np.clip(usage_intensity, 0.75, 1.35) * age_pressure)

        regular_count = np.random.poisson(max(0.0, regular_expected))
        issue_count = np.random.poisson(max(0.0, issue_expected))
        total_count = int(min(12, regular_count + issue_count))
        if total_count == 0:
            continue

        possible_start = acq_date + pd.Timedelta(days=90)
        possible_days = max((end_date - possible_start).days, 1)
        event_offsets = sorted(random.sample(range(possible_days), k=min(total_count, possible_days)))

        for offset in event_offsets:
            event_date = possible_start + pd.Timedelta(days=int(offset))
            life_ratio = np.clip((event_date - acq_date).days / (content_life * 365.0), 0, 1.8)
            is_regular = random.random() < max(0.20, 0.72 - life_ratio * 0.28)

            if is_regular:
                event_type = "정기점검"
                severity = 0 if random.random() < 0.75 else 1
                result = "정상" if severity == 0 else "경미수리"
            else:
                severity_probs = [0.10, 0.48, 0.32, 0.10] if life_ratio < 1.0 else [0.05, 0.30, 0.45, 0.20]
                severity = int(np.random.choice([0, 1, 2, 3], p=severity_probs))
                if severity <= 1:
                    event_type = "장애점검"
                    result = "경미수리"
                elif severity == 2:
                    event_type = "수리"
                    result = "주요수리"
                else:
                    event_type = "부품교체"
                    result = "교체권고" if life_ratio >= 0.95 and random.random() < 0.45 else "주요수리"

            if result == "정상":
                cost = 0
            elif result == "경미수리":
                cost = int(price * random.uniform(0.01, 0.03))
            elif result == "주요수리":
                cost = int(price * random.uniform(0.05, 0.12))
            else:
                cost = int(price * random.uniform(0.08, 0.18))
            cost = min(cost, int(price * 0.30))
            cost = (cost // 1000) * 1000

            maintenance_rows.append({
                "점검수리일자": event_date.strftime("%Y-%m-%d"),
                "물품고유번호": asset_id,
                "G2B_목록번호": row.G2B_목록번호,
                "G2B_목록명": item_name,
                "운용부서": getattr(row, "운용부서", ""),
                "점검수리구분": event_type,
                "처리결과": result,
                "수리비용": cost,
                "장애심각도": severity,
                "비고": f"{item_name} {event_type}"
            })

    return pd.DataFrame(maintenance_rows)
# [Professor Fix 3 + User Requirement] 자산 ID 생성 방식 개선 (하이브리드)
# 기존 포맷(M+연도+시퀀스)을 유지하되, 정렬 기준을 고정하여 재현성 확보
def create_asset_ids(df: pd.DataFrame) -> pd.Series:
    """
    형식: M{연도(4)}{시퀀스(5)} -> 예: M202400001
    개선점: 모든 컬럼 정보(Tie-Breaker)를 포함한 안정 정렬을 사용하여
            입력 순서가 바뀌어도 ID 부여 결과가 항상 동일하도록 보장
    """
    # 원본 인덱스 보존
    df_temp = df.copy()
    
    # 1. 연도 추출
    df_temp['temp_year'] = pd.to_datetime(df_temp['취득일자']).dt.year
    
    # 2. [Tie-Breaker] 동률 처리를 위한 '행 내용 기반' 정렬 키 생성
    #    모든 컬럼 값을 문자열로 이어붙여서, 내용이 조금이라도 다르면 순서가 고정되게 함
    df_temp['row_content_hash'] = df_temp.astype(str).sum(axis=1)
    
    # 3. [핵심] 완전 결정적 정렬 (Deterministic Sort)
    # 정렬 키: 연도 -> 부서 -> 품목 -> 금액 -> 날짜 -> 비고 -> (Tie-Breaker)내용해시
    sort_cols = ['temp_year', '운용부서코드', 'G2B_목록번호', '취득금액', '취득일자', '비고', 'row_content_hash']
    
    # 존재하는 컬럼만 필터링 (안전장치)
    valid_sort_cols = [col for col in sort_cols if col in df_temp.columns]
    
    df_temp = df_temp.sort_values(
        by=valid_sort_cols,
        ascending=[True] * len(valid_sort_cols),
        kind='mergesort' # [Review Fix] Stable Sort 사용 (동률 시 순서 유지 보장)
    )
    
    # 4. 연도별 그룹핑 후 시퀀스 생성 (1, 2, 3...)
    df_temp['temp_seq'] = df_temp.groupby('temp_year').cumcount() + 1
    
    # 5. ID 조합 (M + 2024 + 00001)
    df_temp['asset_id'] = (
        'M' + 
        df_temp['temp_year'].astype(str) + 
        df_temp['temp_seq'].astype(str).str.zfill(5)
    )
    
    # 6. 원래 순서대로 정렬하여 ID 시리즈 반환
    return df_temp['asset_id'].sort_index()

def normalize_history_timestamp(value):
    dt = pd.to_datetime(value, errors='coerce')
    if pd.isna(dt):
        return ''
    return pd.Timestamp(dt).strftime('%Y-%m-%d %H:%M:%S')


def add_history(asset_id, date_str, prev_stat, curr_stat, reason, user_tuple=STAFF_USER):
    """이력 추가 헬퍼 함수"""
    change_ts = normalize_history_timestamp(date_str)
    results['history'].append({
        '물품고유번호': asset_id,
        '변경일자': change_ts,
        '(이전)운용상태': prev_stat,
        '(변경)운용상태': curr_stat,
        '사유': reason,
        '관리자명': user_tuple[1], '관리자ID': user_tuple[0],
        '등록자명': user_tuple[1], '등록자ID': user_tuple[0]
    })

def get_approval_status_and_date(base_date, prob_dist=None, event_type=None, is_op_req=False):
    """
    승인 상태 및 확정일자 결정
    :param base_date: 기준일자
    :param prob_dist: 승인 상태 선택에 사용할 확률 분포 (STATUS_CHOICES 순서의 리스트 또는 배열)
    :param event_type: 'op_req', 'return', 'disuse', 'disposal' 등 이벤트 종류
    :param is_op_req: 운용 전환신청 여부(True인 경우 운용 전환 신청 전용 승인 로직 사용)
    :return: (status, confirm_date, req_date) 튜플. status는 승인 상태 문자열,
            confirm_date는 실제 승인/처리일자, req_date는 신청/요청일자(대기 상태일 경우 확인일자)
    """
    # 상태 결정
    if is_op_req:
        # 운용 전환신청의 경우 날짜에 따라 확률 다름
        days_diff = (TODAY - base_date).days
        if days_diff <= 14:
            status = np.random.choice(['확정', '대기', '반려'], p=[0.5, 0.4, 0.1])
        else:
            status = np.random.choice(['확정', '반려'], p=[0.99, 0.01])
    else:
        status = np.random.choice(STATUS_CHOICES, p=prob_dist)

    # 날짜 결정
    confirm_date = base_date
    req_date_final = base_date

    if status == '대기':
        min_allowed = max(base_date, RECENT_WAIT_START)

        # 시작일이 오늘보다 미래라면 오늘로 강제 조정
        if min_allowed > TODAY: min_allowed = TODAY
        
        # start_date와 end_date가 같은 경우(또는 역전) 방지
        if min_allowed >= TODAY:
            req_date_final = TODAY
        else:
            temp_date = fake.date_between(start_date=min_allowed, end_date=TODAY)
            req_date_final = datetime(temp_date.year, temp_date.month, temp_date.day)
            
        confirm_date = req_date_final 
        
    elif status == '확정':
        # [Fix] 이벤트 타입에 따라 처리 기간 차등 적용
        days_add = random.randint(3, 14)
        if event_type == 'disuse': days_add = random.randint(14, 30)
        if event_type == 'disposal': days_add = random.randint(30, 90)
        
        confirm_date = base_date + timedelta(days=days_add)
        if confirm_date > TODAY: confirm_date = TODAY
        
    return status, confirm_date, req_date_final

# ---------------------------------------------------------
# 2. 단계별 상세 처리 함수 (Refactoring)
# ---------------------------------------------------------

def step_operation_transfer(ctx, is_direct=False):
    """
    A. 운용 전환 신청 단계 (재사용 또는 직접전환)
    - 반납된 물품을 다른 부서가 사용하겠다고 신청하는 과정
    param is_direct: True면 운용 중 직접 전환, False면 반납 후 재사용
    """
    # sim_cursor_date는 기본적으로 '반납확정일자' 시점이나,
    # is_direct=True 인 경우에는 직접전환 이벤트 발생일(운용 중 전환일)을 의미함
    sim_date = ctx['sim_cursor_date']
    asset_id = ctx['asset_id']
    row = ctx['row']
    
    # 신청일 결정
    if is_direct:
        # 직접 전환은 이벤트 발생일이 곧 신청일
        op_req_date = sim_date
    else:
        # 반납 후 재사용은 반납확정일 + 1~7일 후
        op_req_date = sim_date + timedelta(days=random.randint(1, 7))
    
    if op_req_date > TODAY: return False # 미래 시점이면 종료

    # 승인 상태 및 날짜 계산 (운용전환은 대부분 확정됨)
    status, confirm_date, req_date_fixed = get_approval_status_and_date(op_req_date, event_type='op_req', is_op_req=True)
    
    # 재사용 차수 증가 (직접전환이든 재사용이든 횟수 차감하여 제한)
    reuse_cnt = ctx.get('reuse_count', 0) + 1
    ctx['reuse_count'] = reuse_cnt
    
    # 신청 구분 및 비고 멘트, 반려 시 상태 설정
    new_dept = ctx['curr_dept_name']
    if is_direct:
        req_type = '운용전환(직접)'
        transfer_remark = f"{new_dept}로 운용전환(직접인계) 신청"
        prev_stat_log = '운용'
        fail_fallback_status = '운용' # 반려되면 그냥 운용 상태 유지
    else:
        req_type = '운용전환(재사용)'
        transfer_remark = f"{new_dept}에서 운용전환(재사용) 신청(재사용 {reuse_cnt}회차)"
        prev_stat_log = '반납'
        fail_fallback_status = '반납' # 반려되면 반납 상태 유지

    # 승인 상태에 따른 표시 상태 (확정되면 '운용', 아니면 이전 상태인 '반납' 유지)
    if status == '확정':
        display_status = '운용'
    else:
        display_status = fail_fallback_status

    results['transfer'].append({
        '운용전환일자': req_date_fixed.strftime('%Y-%m-%d'),
        '등록일자': req_date_fixed.strftime('%Y-%m-%d'),
        '운용확정일자': confirm_date.strftime('%Y-%m-%d') if status == '확정' else '',
        '등록자ID': STAFF_USER[0], '등록자명': STAFF_USER[1],
        '승인상태': status,
        'G2B_목록번호': row.G2B_목록번호, 'G2B_목록명': row.G2B_목록명,
        '물품고유번호': asset_id, 
        '취득일자': row.취득일자, '취득금액': row.취득금액,
        '운용부서': ctx['curr_dept_name'], 
        '물품상태': ctx.get('curr_condition'),
        '사유': transfer_remark, # 전환 신청 내용 기록
        '신청구분': req_type,
        '운용상태': display_status
    })
    
    if status != '확정': return False # 확정 안되면 시뮬레이션 중단

    # 상태 업데이트
    use_start_date = confirm_date
    ctx['sim_cursor_date'] = use_start_date
    ctx['prev_status'] = prev_stat_log
    ctx['curr_status'] = '운용'
    
    # [Fix] 코드 리뷰 반영: 새로운 운용 시작일을 컨텍스트에 기록 (반납 시 사용 기간 계산용)
    ctx['last_operation_start_date'] = confirm_date

    # 운용대장 업데이트 (메모리 상)
    ctx['df_operation'].at[ctx['idx'], '운용상태'] = '운용'
    ctx['df_operation'].at[ctx['idx'], '운용부서'] = ctx['curr_dept_name']
    ctx['df_operation'].at[ctx['idx'], '운용부서코드'] = ctx['curr_dept_code']
    ctx['df_operation'].at[ctx['idx'], '운용확정일자'] = confirm_date.strftime('%Y-%m-%d')
    
    # 이력 추가
    add_history(asset_id, confirm_date.strftime('%Y-%m-%d'), prev_stat_log, '운용', f'{req_type} 승인 ({new_dept})')
    
    return True

def step_determine_event(ctx):
    """
    B. 운용 중 차기 사건 발생일 결정 (Look-ahead 상세 버전)
    기존의 모든 확률 및 기간 조건(30일/90일/3년/5년)을 유지하며 미래 시점을 계산합니다.
    """
    sim_date = ctx['sim_cursor_date']  # 현재 시뮬레이션 시점
    row = ctx['row']
    acq_date = pd.to_datetime(row.취득일자)
    use_start_date = pd.to_datetime(ctx['df_operation'].at[ctx['idx'], '운용확정일자'])
    
    # 현실적 기대 수명 (고정 미래 시점)
    limit_real = ctx.get('assigned_limit_days', 365*5)
    
    # 발생 가능한 이벤트 후보 리스트
    candidates = []

    # -----------------------------------------------------------
    # 1. [불용 예정일] 물리적 수명 도달 시점 계산
    # -----------------------------------------------------------
    eol_date = acq_date + timedelta(days=limit_real)
    # EOL이 오늘(TODAY) 이전/당일이면 발생 가능 후보에 추가하되,
    # 실제 발생일은 시뮬레이션 커서(sim_date)보다 과거로 가지 않도록 보정
    if eol_date <= TODAY:
        eol_event_date = max(sim_date, eol_date)
        eol_event_date = apply_institutional_cycle(eol_event_date, 'disuse')
        candidates.append(('불용신청', eol_event_date))

    # -----------------------------------------------------------
    # 2. [직접전환 예정일] 운용 중 부서 이동 (Look-ahead)
    # -----------------------------------------------------------
    # 조건: 사용 시작 후 최소 90일은 지나야 하고, 수명의 80% 이내여야 함
    if random.random() < PROB_DIRECT_TRANSFER:
        # 발생 가능 시작일: (사용 시작 90일 후)와 (현재 시점) 중 늦은 날
        earliest_possible = max(sim_date, use_start_date + timedelta(days=90))
        # 발생 가능 종료일: 수명의 80% 시점
        latest_possible = acq_date + timedelta(days=int(limit_real * 0.8))
        
        if earliest_possible < latest_possible and earliest_possible <= TODAY:
            # [Copilot 리뷰 반영] 발생 가능 종료일을 넘지 않도록 랜덤 범위 제한
            max_days_allowed = (latest_possible - earliest_possible).days
            # 최소 10일에서 최대 180일 사이로 하되, 가용 기간(max_days_allowed)을 넘지 않도록 설정
            days_to_add = random.randint(10, max(10, min(180, max_days_allowed)))
            transfer_date = earliest_possible + timedelta(days=days_to_add)
            
            if sim_date <= transfer_date <= min(latest_possible, TODAY):
                candidates.append(('직접전환', transfer_date))

    # -----------------------------------------------------------
    # 3. [반납 예정일] 업무적 사유에 의한 발생 (Look-ahead)
    # -----------------------------------------------------------
    is_return_triggered = False
    return_date = None

    # (1) 조기 반납 (1% 확률)
    if random.random() < PROB_EARLY_RETURN:
        # 시뮬레이션 시점 기준 1~30일 이내 발생
        return_date = sim_date + timedelta(days=random.randint(1, 30))
        is_return_triggered = True

    # (2) 사용 기간에 따른 일반 반납 확률 (조기 반납 안 터졌을 때)
    if not is_return_triggered:
        age_days_at_sim = (sim_date - acq_date).days
        prob = 0
        if age_days_at_sim > (365 * 5):
            prob = PROB_RETURN_OVER_5Y
        elif age_days_at_sim > (365 * 3):
            prob = PROB_RETURN_OVER_3Y
        
        if random.random() < prob:
            # 조건: 최소 30일은 사용 후 반납 (기존 로직 유지)
            earliest_ret = max(sim_date, use_start_date + timedelta(days=30))
            return_date = earliest_ret + timedelta(days=random.randint(30, 365))
            is_return_triggered = True

    # 반납이 확정되었고 날짜가 범위 내라면 후보 추가
    if is_return_triggered and return_date:
        if sim_date <= return_date <= TODAY:
            candidates.append(('반납', return_date))

    # -----------------------------------------------------------
    # 4. [최종 결정] 가장 먼저 터지는 사건 선택
    # -----------------------------------------------------------
    if not candidates:
        # 아무 일도 일어나지 않으면 시뮬레이션 종료 시점(오늘+1) 반환
        return '유지', TODAY + timedelta(days=1)

    # 날짜 순으로 정렬하여 가장 빠른 이벤트 반환
    candidates.sort(key=lambda x: x[1])
    return candidates[0]

def step_process_return(ctx, event_date):
    """
    C-1. 반납 처리 및 재사용 여부 결정
    """
    # 1. 반납 사유 결정
    reason = np.random.choice(REASONS_RETURN, p=PROBS_RETURN_REASON)
    
    # 2. 물품 상태 결정
    if reason == '잉여물품':
        condition = '신품'
    elif reason == '사업종료':
        condition = np.random.choice(['신품', '중고품','요정비품'], p=[0.4, 0.5, 0.1])
    elif reason == '공용전환':
        condition = np.random.choice(['신품', '중고품'], p=[0.3, 0.7])
    
    ctx['curr_condition'] = condition

    # 3. 승인 처리
    status, confirm_date, req_date = get_approval_status_and_date(
        event_date,
        PROBS_STATUS_RETURN,
        event_type='return'
    )
    confirm_str = confirm_date.strftime('%Y-%m-%d') if status == '확정' else ''

    # 반납 리스트 저장 시, 확정 상태여야만 '반납'으로 표기, 아니면 기존 '운용' 유지
    display_status = '반납' if status == '확정' else '운용'

    # 반납 리스트 저장
    results['return'].append({
        '반납일자': req_date.strftime('%Y-%m-%d'),
        '반납확정일자': confirm_str,
        '등록자ID': STAFF_USER[0], '등록자명': STAFF_USER[1],
        '승인상태': status,
        'G2B_목록번호': ctx['row'].G2B_목록번호, 'G2B_목록명': ctx['row'].G2B_목록명,
        '물품고유번호': ctx['asset_id'], 
        '취득일자': ctx['row'].취득일자,'취득금액': ctx['row'].취득금액,
        '정리일자': ctx['clear_date_str'], 
        '운용부서': ctx['curr_dept_name'], '운용상태': display_status,
        '물품상태': condition, '사유': reason
    })

    if status == '확정':
        # 대장 및 이력 업데이트
        ctx['df_operation'].at[ctx['idx'], '운용상태'] = '반납'
        ctx['df_operation'].at[ctx['idx'], '운용부서'] = ''
        ctx['prev_status'] = '운용'
        ctx['curr_status'] = '반납'
        add_history(ctx['asset_id'], confirm_str, '운용', '반납', reason)
        
        ctx['sim_cursor_date'] = confirm_date
        
        # 반납 후 처리 경로
        # 1. 재사용 (부서 재배정)
        # A. 신품이거나
        # B. 중고품인데 사용한지 얼마 안 된 것 (RECENT_USE_LIMIT_DAYS 이내)
        # 2. 불용 진행 (재활용 불가 판단 등)
        acq_dt = pd.to_datetime(ctx['row'].취득일자)
        # 최근 운용 시작일을 기준으로 사용 기간 계산 (없으면 취득일자 기준)
        operation_start_dt = ctx.get('last_operation_start_date')
        if isinstance(operation_start_dt, str):
            operation_start_dt = pd.to_datetime(operation_start_dt)
        base_dt = operation_start_dt if operation_start_dt is not None and not pd.isna(operation_start_dt) else acq_dt
        days_used = (confirm_date - base_dt).days
        is_recent_used = (condition == '중고품' and days_used <= RECENT_USE_LIMIT_DAYS)
        
        can_reuse = (condition == '신품') or is_recent_used
        
        # 후보군 중에서 '아주 소수'만 실제로 재사용 신청
        if can_reuse and random.random() < PROB_REUSE_FROM_RETURN:
            # 부서 변경
            new_dept = random.choice(DEPT_MASTER_DATA)
            ctx['curr_dept_code'] = new_dept[0]
            ctx['curr_dept_name'] = new_dept[1]
            return '재사용', reason
        else:
            # 재사용 안되면 불용 처리
            return '불용진행', reason
            
    return '종료', reason

def step_process_disuse(ctx, trigger_event, inherited_reason=None):
    """C-2. 불용 및 처분 처리"""
    # 1. 불용 사유 및 상태 결정    
    if trigger_event == '불용신청':
        # [NEW] 현실 수명이 다해서 오는 경우 -> 물리적 사유 선택
        reason = np.random.choice(REASONS_PHYSICAL_END, p=PROBS_PHYSICAL_END_REASON)
        condition = '폐품' # 모든 불용 상태는 폐품으로 통일
        prev_stat = '운용' # 반납 거치지 않고 바로 옴
        
    elif trigger_event == '불용진행':
        # 반납 후 불용으로 넘어오는 경우 (사유 상속 또는 매핑)
        # 사유: 활용부서 부재, 구형화 등
        if inherited_reason in ['잉여물품', '사업종료','공용전환']:
            reason = np.random.choice(['활용부서부재', '구형화'], p =[0.7, 0.3])
        # else:
        #     reason = inherited_reason # 공용전환 등
            
        condition = ctx['curr_condition']
        prev_stat = '반납'
        
        # 잉여물품 보관 스킵 로직 (확률적으로 불용 안하고 창고 보관 -> 시뮬 종료)
        if inherited_reason == '잉여물품' and condition == '신품':
             if random.random() < PROB_SURPLUS_STORE: return # 불용 기록 안하고 종료

    else:
        reason = '기타'
        condition = '폐품'
        prev_stat = '운용'
    
    # 2. 불용 승인 처리
    du_date = ctx['sim_cursor_date'] + timedelta(days=random.randint(1, 14))
    du_date = apply_institutional_cycle(du_date, 'disuse')
    if du_date > TODAY: du_date = TODAY

    status, confirm_date, req_date = get_approval_status_and_date(
        du_date,
        PROBS_STATUS_DISUSE,
        event_type='disuse'
    )
    confirm_str = confirm_date.strftime('%Y-%m-%d') if status == '확정' else ''

    # 불용 리스트 저장 시, 확정 상태여야만 '불용'으로 표기, 아니면 기존 상태 유지
    if status == '확정':
        display_status = '불용'
    else:
        display_status = prev_stat

    # 불용 데이터 저장
    results['disuse'].append({
        '불용일자': req_date.strftime('%Y-%m-%d'),
        '불용확정일자': confirm_str,
        '등록자ID': STAFF_USER[0], '등록자명': STAFF_USER[1],
        '승인상태': status,
        'G2B_목록번호': ctx['row'].G2B_목록번호, 'G2B_목록명': ctx['row'].G2B_목록명,
        '물품고유번호': ctx['asset_id'], 
        '취득일자': ctx['row'].취득일자, '취득금액': ctx['row'].취득금액,
        '정리일자': ctx['clear_date_str'],
        '운용부서': ctx['curr_dept_name'], 
        '운용상태' : display_status,
        '내용연수': ctx['row'].내용연수,
        '물품상태': condition, '사유': reason
    })

    # 대장 업데이트
    if status == '확정':
        ctx['df_operation'].at[ctx['idx'], '운용상태'] = '불용'
        add_history(ctx['asset_id'], confirm_str, prev_stat, '불용', reason, ADMIN_USER)
        ctx['sim_cursor_date'] = confirm_date


    # 처분 진행 (불용 확정시에만)
    if status == '확정':
        step_process_disposal(ctx, condition, reason)

def step_process_disposal(ctx, condition, disuse_reason):
    """C-3. 처분 처리"""
    dp_date = ctx['sim_cursor_date'] + timedelta(days=random.randint(1, 14))
    dp_date = apply_institutional_cycle(dp_date, 'disposal')
    if dp_date > TODAY: dp_date = TODAY

    # 처분 방식
    probs = PROBS_DISPOSAL_GOOD if condition in ['신품', '중고품'] else PROBS_DISPOSAL_BAD
    method = np.random.choice(METHODS_DISPOSAL, p=probs)

    status, confirm_date, req_date = get_approval_status_and_date(
        dp_date,
        PROBS_STATUS_DISPOSAL,
        event_type='disposal'
    )
    confirm_str = confirm_date.strftime('%Y-%m-%d') if status == '확정' else ''

    if status == '확정':
        ctx['df_operation'].at[ctx['idx'], '운용상태'] = '처분'
        add_history(ctx['asset_id'], confirm_str, '불용', '처분', f"{method} 완료", ADMIN_USER)

    results['disposal'].append({
        '처분일자': req_date.strftime('%Y-%m-%d'),
        '처분확정일자': confirm_str,
        '처분정리구분': method,
        '등록자ID': STAFF_USER[0], '등록자명': STAFF_USER[1],
        '승인상태': status,
        'G2B_목록번호': ctx['row'].G2B_목록번호, 'G2B_목록명': ctx['row'].G2B_목록명,
        '물품고유번호': ctx['asset_id'], 
        '취득일자': ctx['row'].취득일자, '취득금액': ctx['row'].취득금액,
        '처분방식': method, '물품상태': condition, '사유': disuse_reason,
        '불용일자': ctx['sim_cursor_date'].strftime('%Y-%m-%d'),
        '내용연수': ctx['row'].내용연수, '정리일자': ctx['clear_date_str'],
    })

# ---------------------------------------------------------
# 3. 메인 시뮬레이션 루프
# ---------------------------------------------------------

# 데이터 전처리 (Explosion & ID Generation)
print("⚙️ [Phase 2] 개별 자산 분화 및 고유번호 생성 중...")
df_confirmed = df_acq[df_acq['승인상태'] == '확정'].copy()
df_operation = df_confirmed.loc[df_confirmed.index.repeat(df_confirmed['수량'])].reset_index(drop=True)

df_operation['취득금액'] = (df_operation['취득금액'] / df_operation['수량']).fillna(0).astype('int64')
df_operation['수량'] = 1
df_operation['물품고유번호'] = create_asset_ids(df_operation)
# [수정] 초기 상태를 '운용'으로 설정 (취득 즉시 운용대장 등재)
df_operation['운용상태'] = '운용' 
# [수정] 최초 운용 등재 시 PROBS_PRINT_STATUS 확률로 출력상태 설정
df_operation['출력상태'] = np.random.choice(
    ['출력', '미출력'],
    size=len(df_operation),
    p=PROBS_PRINT_STATUS
)

# [수정] 초기 운용확정일자는 취득 정리일자와 동일하게 설정
df_operation['운용확정일자'] = df_operation['정리일자'].fillna(df_operation['취득일자'])

# Phase 1 보강 컬럼이 없는 과거 데이터로 실행해도 깨지지 않도록 기본값을 보강한다.
enhancement_defaults = {
    '구매배치ID': '',
    '구매배치수량': 1,
    '대량구매여부': 0,
    '부서예산등급': 'MEDIUM',
    '부서교체성향': 1.0,
    '부서관리성향': 1.0,
}
for col, default in enhancement_defaults.items():
    if col not in df_operation.columns:
        df_operation[col] = default

missing_batch_mask = df_operation['구매배치ID'].isna() | (df_operation['구매배치ID'].astype(str).str.strip() == '')
df_operation.loc[missing_batch_mask, '구매배치ID'] = (
    'B' + pd.to_datetime(df_operation.loc[missing_batch_mask, '취득일자'], errors='coerce').dt.year.fillna(TODAY.year).astype(int).astype(str)
    + df_operation.loc[missing_batch_mask, '물품고유번호'].astype(str).str[-5:]
)
df_operation['구매배치수량'] = pd.to_numeric(df_operation['구매배치수량'], errors='coerce').fillna(1).astype(int)
df_operation['대량구매여부'] = pd.to_numeric(df_operation['대량구매여부'], errors='coerce').fillna(0).astype(int)
df_operation['부서교체성향'] = pd.to_numeric(df_operation['부서교체성향'], errors='coerce').fillna(1.0)
df_operation['부서관리성향'] = pd.to_numeric(df_operation['부서관리성향'], errors='coerce').fillna(1.0)

usage_profiles = df_operation.apply(
    lambda r: pd.Series(derive_usage_profile(
        r['G2B_목록명'],
        r['운용부서'],
        r.get('부서예산등급', 'MEDIUM'),
        r.get('부서관리성향', 1.0),
    )),
    axis=1
)
df_operation = pd.concat([df_operation, usage_profiles], axis=1)

print("⏳ [Phase 2] 자산 생애주기 시뮬레이션 시작 (운용 Loop)...")

for row in df_operation.itertuples():
    # Context 객체: 함수 간 상태 공유용
    clear_date = pd.to_datetime(row.정리일자) if pd.notna(row.정리일자) else pd.to_datetime(row.취득일자)
    # ---------------------------------------------------------
    # [NEW] 1. 물품별 현실적 기대 수명(Natural Life Limit) 계산
    # 우선 기본값 설정 ("default" 키는 설정에 반드시 존재해야 함)
    mu, sigma = REAL_LIFETIME_STATS.get("default", (5.0, 1.5))
    
    # 목록명이나 분류명에서 키워드 검색하여 통계 적용
    # 대소문자 무시 및 긴 키워드 우선 매칭 적용
    target_name = str(row.G2B_목록명)
    target_name_norm = target_name.strip().casefold()
    
    # 키워드 길이 역순 정렬 (구체적인 단어가 먼저 매칭되도록)
    sorted_keys = sorted(REAL_LIFETIME_STATS.keys(), key=len, reverse=True)
    
    for key in sorted_keys:
        if key == "default": continue # default는 루프 밖에서 처리하거나 마지막에
        
        # casefold()로 대소문자 무시 비교
        if key.casefold() in target_name_norm:
            mu, sigma = REAL_LIFETIME_STATS[key]
            break
            
    # [NEW] 2. 양수 수명 분포에서 샘플링 및 AI용 패턴 부여
    # - 품목군에 따라 Weibull/Lognormal 분포를 사용해 현실적인 변동성과 긴 꼬리를 반영
    base_life_years = sample_positive_life_years(target_name_norm, mu, sigma)
    
    # ---------------------------------------------------------
    # [NEW] 3. 데이터 패턴 부여: AI 모델 학습을 위한 가중치 적용 
    # ---------------------------------------------------------
    
    # 1) 부서가혹도에 따른 수명 단축 (험한 곳은 빨리 고장남)
    # [Copilot 반영] 우선순위 명시: 가혹도가 높은 '소프트웨어/공학(1.3)'을 먼저 검사하여 적용합니다.
    dept_name = str(row.운용부서)
    severity_divisor = 1.0 # [Copilot 반영] 나누는 값이라는 것을 명확히 하기 위해 변수명 변경 (factor -> divisor)
    
    if any(k in dept_name for k in ['소프트웨어', '공학', '전산', 'AI', '정보', '공과', '컴퓨터']):
        severity_divisor = 1.3
    elif any(k in dept_name for k in ['연구', '실험', '과학']):
        severity_divisor = 1.2
        
    # 2) 취득금액(리드타임등급)에 따른 수명 연장 (비싼 고가 장비는 내구성이 좋음)
    # [Copilot 반영] 품목군에 따라 고가/중가 장비의 기준 금액을 다르게 적용
    price = float(row.취득금액) if pd.notna(row.취득금액) else 0.0
    
    # 기본 임계값 (IT 기기, 장비류 기준)
    high_tier = 30000000 # 3천만 원
    mid_tier = 5000000   # 5백만 원
    
    # 가구류 등은 기준을 대폭 낮춤
    if any(k in target_name_norm for k in ['책상', '의자', '캐비닛', '가구', '랙', '실습대']):
        high_tier = 1000000  # 가구는 100만 원 이상이면 고급
        mid_tier = 300000    # 가구는 30만 원 이상이면 중급
        
    if price >= high_tier:
        price_factor = 1.15  # 수명 15% 연장
    elif price >= mid_tier:
        price_factor = 1.05  # 수명 5% 연장
    else:
        price_factor = 1.0   # 일반 장비
        
    # 3) 관리상태/운용환경의 관측되지 않는 차이를 작게 반영
    maintenance_factor = np.random.choice([0.9, 1.0, 1.08], p=[0.15, 0.70, 0.15])
    random_usage_jitter = np.random.uniform(0.92, 1.08)

    # 최종 수명 확정 = 기본수명 * (1 / 가혹도) * (1 / 사용강도) * 가격/관리/정책 보정
    # [Copilot 반영] severity_factor 대신 severity_divisor 사용
    usage_divisor = float(np.clip(getattr(row, '사용강도지수', 1.0), 0.90, 1.25))
    dept_management_factor = float(np.clip(getattr(row, '부서관리성향', 1.0), 0.90, 1.10))
    replacement_tendency = float(np.clip(getattr(row, '부서교체성향', 1.0), 0.90, 1.15))
    policy_divisor = float(np.clip(1.0 + ((replacement_tendency - 1.0) * 0.5), 0.95, 1.08))
    assigned_life_years = (
        base_life_years
        * (1.0 / severity_divisor)
        * (1.0 / usage_divisor)
        * price_factor
        * maintenance_factor
        * dept_management_factor
        * random_usage_jitter
        * (1.0 / policy_divisor)
    )
    
    # [Copilot 반영] 최소 수명 방어선을 0.5년에서 현실적인 1.0년(1년)으로 상향
    assigned_life_years = max(MIN_LIFE_YEARS, assigned_life_years) 
    
    # 일(Day) 단위로 변환
    assigned_limit_days = int(assigned_life_years * 365)

    ctx = {
        'idx': getattr(row, 'Index', 0), # 인덱스 안전하게 가져오기
        'row': row,
        'asset_id': row.물품고유번호,
        'sim_cursor_date': clear_date,
        'clear_date_str': clear_date.strftime('%Y-%m-%d'),
        'curr_dept_name': row.운용부서,
        'curr_dept_code': row.운용부서코드,

        # [수정] 초기 상태 '운용'으로 시작
        'curr_status': '운용', 
        'prev_status': '취득',

        'curr_condition': '신품',
        'reuse_count': 0,
        'df_operation': df_operation,
        'assigned_limit_days': assigned_limit_days,  # <--- 현실 수명 할당
        'last_operation_start_date': clear_date,
    }
    # 1. 취득 이력 생성 (동일 일자 내에서 운용 이력보다 먼저 발생하도록 미세 시간차 부여)
    acq_dt = datetime.combine(clear_date.date(), datetime.min.time())
    op_dt = acq_dt + timedelta(seconds=1)
    acq_dt_str = acq_dt.strftime('%Y-%m-%d %H:%M:%S')
    op_dt_str = op_dt.strftime('%Y-%m-%d %H:%M:%S')
    add_history(ctx['asset_id'], acq_dt_str, '-', '취득', '신규 취득')

    # 2. 곧바로 운용 등재 (전산상 자동 전환)
    add_history(ctx['asset_id'], op_dt_str, '취득', '운용', '신규 운용 등재')
    # ==========================================================================
    # [NEW] 특수 물품(서버) 전용 로직 (시뮬레이션 루프 패스)
    # ==========================================================================
    if "통신서버" in row.G2B_목록명:
        # 1) 날짜 및 기본 정보 세팅
        acq_dt = pd.to_datetime(row.취득일자)
        op_start_date = ctx['sim_cursor_date'] + timedelta(days=random.randint(1, 7))
        if op_start_date > TODAY: op_start_date = TODAY

        # [Fix] 코드 리뷰 반영: 서버의 최초 운용 시작일 기록
        ctx['last_operation_start_date'] = op_start_date

        # 서버는 관리태그 부착 필수 (초기 랜덤값 무시하고 강제 설정)
        df_operation.at[ctx['idx'], '출력상태'] = '출력'

        # 2) 구형 서버 (2020년 이전) -> 운용하다가 불용/처분됨
        if acq_dt.year < 2020:
            # 내용연수 6년 + 알파 시점에 불용
            life_years = 6
            disuse_date = acq_dt + timedelta(days=365*life_years + random.randint(0, 60))
            disuse_date = apply_institutional_cycle(disuse_date, 'disuse')
            
            # 불용 리스트 추가
            disuse_reason = '내구연한 경과(노후화)'
            results['disuse'].append({
                '불용일자': disuse_date.strftime('%Y-%m-%d'),
                '불용확정일자': disuse_date.strftime('%Y-%m-%d'),
                '등록자ID': STAFF_USER[0], '등록자명': STAFF_USER[1],
                '승인상태': '확정',
                'G2B_목록번호': row.G2B_목록번호, 'G2B_목록명': row.G2B_목록명,
                '물품고유번호': ctx['asset_id'], 
                '취득일자': row.취득일자, '취득금액': row.취득금액,
                '정리일자': row.정리일자, '운용부서': row.운용부서, 
                '운용상태' : '불용', '내용연수': row.내용연수,
                '물품상태': '폐품', '사유': disuse_reason
            })
            
            # 대장 상태 변경
            df_operation.at[ctx['idx'], '운용상태'] = '불용'
            add_history(ctx['asset_id'], disuse_date.strftime('%Y-%m-%d'), '운용', '불용', disuse_reason, ADMIN_USER)

            # 처분 (매각)
            disposal_date = disuse_date + timedelta(days=random.randint(30, 90))
            disposal_date = apply_institutional_cycle(disposal_date, 'disposal')
            if disposal_date > TODAY: disposal_date = TODAY # 미래 방지

            results['disposal'].append({
                '처분일자': disposal_date.strftime('%Y-%m-%d'),
                '처분확정일자': disposal_date.strftime('%Y-%m-%d'),
                '처분정리구분': '매각',
                '등록자ID': STAFF_USER[0], '등록자명': STAFF_USER[1],
                '승인상태': '확정',
                'G2B_목록번호': row.G2B_목록번호, 'G2B_목록명': row.G2B_목록명,
                '물품고유번호': ctx['asset_id'], 
                '취득일자': row.취득일자, '취득금액': row.취득금액,
                '처분방식': '매각', '물품상태': '폐품', '사유': disuse_reason,
                '불용일자': disuse_date.strftime('%Y-%m-%d'),
                '내용연수': row.내용연수, '정리일자': row.정리일자
            })

            # 최종 상태 변경
            df_operation.at[ctx['idx'], '운용상태'] = '처분'
            add_history(ctx['asset_id'], disposal_date.strftime('%Y-%m-%d'), '불용', '처분', '매각 완료', ADMIN_USER)

        # 4) 신형 서버 (2020년 이후) -> 그냥 '운용' 상태 유지 (별도 코드 필요 없음)
        
        continue # [중요] 아래 while 루프(랜덤 시뮬레이션)를 건너뜀
    # ==========================================================================

    # 2. Lifecycle Loop (운용 -> 반납 -> 운용전환(재사용)/불용 -> 처분)
    while ctx['reuse_count'] <  MAX_REUSE_CYCLES:

        # A. 이벤트 결정 (유지, 반납, 불용신청, 직접전환)
        event_type, event_date = step_determine_event(ctx)

        if event_type == '유지':
            break
        
        # 모든 이벤트 처리 전에 시뮬레이션 커서를 이벤트 발생 시점으로 이동
        ctx['sim_cursor_date'] = event_date

        # [NEW] B-0. 운용 중 직접 전환 (소수 케이스)
        if event_type == '직접전환':
            ctx['sim_cursor_date'] = event_date
            # 부서 변경 (랜덤)
            new_dept = random.choice(DEPT_MASTER_DATA)
            ctx['curr_dept_code'] = new_dept[0]
            ctx['curr_dept_name'] = new_dept[1]
            
            # 직접 전환 신청 수행 (is_direct=True)
            if step_operation_transfer(ctx, is_direct=True):
                continue # 성공 시 루프 유지 (새 부서에서 운용 시작)
            else:
                break # 실패 시 종료

        # B-1. 반납 처리
        elif event_type == '반납':
            result_action, reason = step_process_return(ctx, event_date)
            
            if result_action == '재사용':
                # 재사용이 결정되면 -> 운용 전환 신청(Operation Transfer) 수행
                # 반납 후 재사용 신청 (is_direct=False)
                if step_operation_transfer(ctx, is_direct=False):
                    # 운용 전환 성공 시, 다시 루프 처음(운용 상태)으로 돌아가서 다음 이벤트 대기
                    continue 
                else:
                    break # 신청 반려 시 종료
            
            elif result_action == '불용진행':
                step_process_disuse(ctx, '불용진행', inherited_reason=reason)
                break # 불용으로 가면 운용 루프는 끝
            else:
                break # 종료

        # B-2. 물리적 수명 만료 (불용신청)
        elif event_type == '불용신청':
            ctx['sim_cursor_date'] = event_date
            step_process_disuse(ctx, '불용신청')
            break

# ---------------------------------------------------------
# 4. 파일 저장
# ---------------------------------------------------------
print("💾 [Phase 2] 결과 저장 중...")

# 각 CSV별 컬럼 정의 (빈 결과가 나와도 헤더를 유지하기 위함)
COLS_TRANSFER = [
    '운용전환일자', '등록일자', '운용확정일자', '등록자ID', '등록자명', '승인상태',
    'G2B_목록번호', 'G2B_목록명', '물품고유번호', '취득일자', '취득금액', '운용부서',
    '신청구분', '운용상태', '물품상태', '사유'
]
COLS_RETURN = [
    '반납일자', '반납확정일자', '등록자ID', '등록자명', '승인상태', 'G2B_목록번호', 
    'G2B_목록명', '물품고유번호', '취득일자', '취득금액', '정리일자', '운용부서', 
    '운용상태', '물품상태', '사유'
]
COLS_DISUSE = [
    '불용일자', '불용확정일자', '등록자ID', '등록자명', '승인상태', 'G2B_목록번호',
    'G2B_목록명', '물품고유번호', '취득일자', '취득금액', '정리일자', '운용부서',
    '운용상태', '내용연수', '물품상태', '사유'
]
COLS_DISPOSAL = [
    '처분일자', '처분확정일자', '처분정리구분', '등록자ID', '등록자명', '승인상태',
    'G2B_목록번호', 'G2B_목록명', '물품고유번호', '취득일자', '취득금액', '처분방식',
    '물품상태', '사유', '불용일자', '내용연수', '정리일자'
]
COLS_HISTORY = [
    '물품고유번호', '변경일자', '(이전)운용상태', '(변경)운용상태', '사유', 
    '관리자명', '관리자ID', '등록자명', '등록자ID'
]

# 데이터프레임 생성 시 columns 명시
df_op_req = pd.DataFrame(results['transfer'], columns=COLS_TRANSFER)
df_return = pd.DataFrame(results['return'], columns=COLS_RETURN)
df_disuse = pd.DataFrame(results['disuse'], columns=COLS_DISUSE)
df_disposal = pd.DataFrame(results['disposal'], columns=COLS_DISPOSAL)
df_history = pd.DataFrame(results['history'], columns=COLS_HISTORY)
df_maintenance = generate_maintenance_rows(df_operation, df_disuse, df_disposal)

COLS_MAINTENANCE = [
    '점검수리일자', '물품고유번호', 'G2B_목록번호', 'G2B_목록명', '운용부서',
    '점검수리구분', '처리결과', '수리비용', '장애심각도', '비고'
]
df_maintenance = df_maintenance.reindex(columns=COLS_MAINTENANCE)

cols_operation = [
    'G2B_목록번호', 'G2B_목록명', '물품고유번호', '캠퍼스','취득일자', '취득금액', '정리일자', 
    '운용부서', '운용상태', '내용연수', '출력상태', '승인상태', '취득정리구분', '운용부서코드',
    '구매배치ID', '구매배치수량', '대량구매여부', '부서예산등급', '부서교체성향', '부서관리성향',
    '월평균사용시간', '주당사용일수', '공용장비여부', '수업사용여부', '사용강도지수',
    '비고', '운용확정일자'
]

# 1. 비고 등 원본 데이터 병합
if '비고' not in df_operation.columns:
    add_info = df_acq[['취득일자', 'G2B_목록번호', '취득정리구분', '운용부서코드', '비고', '승인상태']].drop_duplicates()
    df_operation = df_operation.merge(
        add_info,
        on=['취득일자', 'G2B_목록번호', '취득정리구분', '운용부서코드', '승인상태'],
        how='left'
    )

# 2. '운용확정일자' 컬럼이 없는 경우 생성 (KeyError 방지)
if '운용확정일자' not in df_operation.columns:
    # 시뮬레이션 루프에서 업데이트되지 않은 경우(예: 로직 타기 전)를 대비해 빈 값으로 생성
    # 하지만 보통 루프 내에서 업데이트 되므로, 여기서는 안전장치로 추가
    df_operation['운용확정일자'] = ''

df_operation[cols_operation].to_csv(os.path.join(DATA_DIR, '04_01_operation_master.csv'), index=False, encoding='utf-8-sig')

df_op_req.to_csv(os.path.join(DATA_DIR, '04_02_operation_transfer_list.csv'), index=False, encoding='utf-8-sig')
df_return.to_csv(os.path.join(DATA_DIR, '04_03_return_list.csv'), index=False, encoding='utf-8-sig')
df_maintenance.to_csv(os.path.join(DATA_DIR, '04_04_maintenance_list.csv'), index=False, encoding='utf-8-sig')
df_disuse.to_csv(os.path.join(DATA_DIR, '05_01_disuse_list.csv'), index=False, encoding='utf-8-sig')
df_disposal.to_csv(os.path.join(DATA_DIR, '06_01_disposal_list.csv'), index=False, encoding='utf-8-sig')
df_history.to_csv(os.path.join(DATA_DIR, '99_asset_status_history.csv'), index=False, encoding='utf-8-sig')

print("🎉 [Phase 2] 생애주기 시뮬레이션 및 파일 생성 완료!")
print(f"   - 총 자산 규모: {len(df_operation)}건")

# [수정] 이력(History) 횟수가 아닌, 현재 대장(Operation) 상의 '최종 상태' 분포를 출력
print("\n📊 [현재 자산 상태 현황]")
current_status_counts = df_operation['운용상태'].value_counts()
for status, count in current_status_counts.items():
    print(f"      └ {status}: {count}건")

# 참고용으로 총 이력 건수만 한 줄로 표시
print(f"\n   (참고: 생성된 전체 상태 변경 이력 로그는 총 {len(df_history)}건 입니다.)")
print(f"   (참고: 생성된 점검/수리 이력은 총 {len(df_maintenance)}건 입니다.)")

# [NEW] 물품별 수량 통계 출력 (Phase 2 결과 기준)
print("\n📦 물품별 보유 수량 (상위 22개):")
print(df_operation['G2B_목록명'].value_counts().head(22))
